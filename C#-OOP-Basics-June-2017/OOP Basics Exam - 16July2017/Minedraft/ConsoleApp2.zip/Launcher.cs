﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Launcher
{
    public static void Main()
    {
        var ci = new CommandInterpreter();
        ci.Run();
    }
}

