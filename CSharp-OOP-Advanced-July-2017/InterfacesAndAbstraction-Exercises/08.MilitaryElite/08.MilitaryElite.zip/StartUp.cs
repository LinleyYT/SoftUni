﻿using System;
using _08.MilitaryElite.Core;

public class StartUp
{
    public static void Main()
    {
        var commandInterpreter = new CommandInterpreter();
        commandInterpreter.Run();
    }
}

