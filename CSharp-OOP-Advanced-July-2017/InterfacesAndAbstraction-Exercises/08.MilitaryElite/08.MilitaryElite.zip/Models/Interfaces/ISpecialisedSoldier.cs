﻿namespace _08.MilitaryElite.Models.Interfaces
{
    public interface ISpecialisedSoldier : IPrivate
    {
        string Corps { get; }
    }
}