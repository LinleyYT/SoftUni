﻿namespace _08.MilitaryElite.Models.Interfaces
{
    public interface IPrivate : ISoldier
    {
        double Salary { get; }
    }
}