﻿public interface ICitizen : IInhabitant
{
    string Name { get; }
    int Age { get; }
}
