﻿public interface IInhabitant
{
    string Id { get; }
}
