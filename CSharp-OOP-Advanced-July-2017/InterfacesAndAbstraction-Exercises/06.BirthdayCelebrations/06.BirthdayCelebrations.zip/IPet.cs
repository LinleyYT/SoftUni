﻿public interface IPet
{
    string Name { get; }
}
