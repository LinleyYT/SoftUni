﻿public interface IRobot : IInhabitant
{
    string Model { get; }
}
