﻿public interface IHeroFactory
{
    IHero CreateHero(string unitType, string name);
}
