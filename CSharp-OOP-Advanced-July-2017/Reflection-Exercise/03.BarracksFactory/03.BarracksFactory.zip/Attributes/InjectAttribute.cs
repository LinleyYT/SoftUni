﻿using System;

namespace _03BarracksFactory.Attributes
{
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = true)]
    public class InjectAttribute : Attribute
    {
        
    }
}