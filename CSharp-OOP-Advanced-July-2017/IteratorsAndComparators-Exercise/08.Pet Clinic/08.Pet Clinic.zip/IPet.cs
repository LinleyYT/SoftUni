﻿namespace _08.Pet_Clinic
{
    public interface IPet
    {
        string Name { get; }
        int Age { get; }
        string Kind { get; }
    }
}